# Daily UI #013: Direct Messaging

A Pen created on CodePen.io. Original URL: [https://codepen.io/supah/pen/jqOBqp](https://codepen.io/supah/pen/jqOBqp).

It's just a concept, a fake chat to design a new daily ui for direct messaging.
Hope you like it :)