# CSS Gradient Animations

A Pen created on CodePen.io. Original URL: [https://codepen.io/DevLorenzo/pen/ExgpvJM](https://codepen.io/DevLorenzo/pen/ExgpvJM).

40+ CSS only background and border animations
You can easily search CSS code for animation with ctrl+f (search for container + number or containerB + number). B stand for Border. 